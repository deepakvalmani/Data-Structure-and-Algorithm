// Lab 7, Part B: find every dictionary word in a grid of letters.
// Usage: wordpuzzle <dictionary_file> <grid_file>

#include <fstream>
#include <iostream>
#include <string>
#include "HashTable.h"
#include "grid.h"
#include "stopwatch.hpp"

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cerr << "Usage: " << argv[0] << " <dictionary_file> <grid_file>\n";
        return 1;
    }
    // argv[1] is the dictionary file, argv[2] is the grid file

    HashTable dict;
    // TODO: insert the words of the dictionary file into dict

    Grid grid = readInGrid(argv[2]);
    if (grid.empty()) {
        std::cerr << "Cannot read grid file " << argv[2] << "\n";
        return 1;
    }

    Stopwatch sw;   // time only the search, not the loading of the dictionary
    int found = 0;
    // TODO: for every starting position (row, col), direction and length >= 3,
    //       print each string that is in dict, e.g.  "N (3, 2):  text"

    std::cout << found << " words found\n";
    std::cout << "Found all words in " << sw.elapsedTime() / 1000 << " seconds\n";
}
