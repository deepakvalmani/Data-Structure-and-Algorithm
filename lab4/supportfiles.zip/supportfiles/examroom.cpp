#include <iostream>
#include <set>

using std::cout, std::set;

class ExamRoom {
private:
    int n_;
    set<int> occupied_;

public:
    ExamRoom(int n) : n_(n) {}

    int seat() {
        // TODO: if the room is empty, seat the student at 0.
        // TODO: otherwise, consider every gap between consecutive
        // occupied seats, plus the gap from seat 0 to the first
        // occupied seat and the gap from the last occupied seat to
        // seat n_ - 1. For each gap, compute the distance from the
        // best seat in that gap to the nearest occupied seat, and
        // pick the gap/seat that maximizes that distance (breaking
        // ties by the smallest seat number).
        // Remember to insert the chosen seat into occupied_ before
        // returning it.
        return -1;
    }

    void leave(int p) {
        // TODO: remove p from occupied_.
    }
};

int main() {
    ExamRoom examRoom(10);
    cout << examRoom.seat() << "\n";  // expected: 0
    cout << examRoom.seat() << "\n";  // expected: 9
    cout << examRoom.seat() << "\n";  // expected: 4
    cout << examRoom.seat() << "\n";  // expected: 2
    examRoom.leave(4);
    cout << examRoom.seat() << "\n";  // expected: 5
}
