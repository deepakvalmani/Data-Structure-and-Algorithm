#pragma once

#include <cmath>
#include <iostream>
#include <map>

// Sparse vector of doubles: only the nonzero entries are stored.
class Svector {
private:
    std::map<int, double> entries_;  // index -> nonzero value

public:
    // Set the i-th entry to x (if x == 0, remove the entry if it exists).
    void set(int i, double x) {
        // TODO
    }

    // Return the i-th entry (0 if not present).
    double get(int i) const {
        // TODO
        return -1; // placeholder return value
    }

    // Dot product of this vector with that, in time proportional to the
    // total number of nonzero entries in both vectors.
    double dot(const Svector& that) const {
        // TODO
        return -1; // placeholder return value
    }

    // Euclidean norm.
    double norm() const {
        // TODO
        return -1; // placeholder return value
    }

    // Sum of this vector and that.
    Svector add(const Svector& that) const {
        // TODO
        return Svector(); // placeholder return value
    }

    // Multiply this vector by alpha (scaling by 0 removes every entry).
    void scale(double alpha) {
        // TODO
    }

    // Print the nonzero entries as {(i1,x1), (i2,x2), ...}
    void print() const {
        // TODO
    }
};
