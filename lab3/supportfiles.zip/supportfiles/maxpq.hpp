#pragma once
#include <vector>
#include <stdexcept>
#include <utility>

template<typename Key>
class MaxPQ {
    private:
        std::vector<Key> pq; // Index 0 is unused

    public:
        MaxPQ() : pq(1) {}

        bool empty() {
            return pq.size() == 1;
        }

        int  size()  {
            return pq.size()-1;
        }

        void insert(const Key& x) {
            // Insert new element at the end of the heap
            // and then swim it to restore heap order
            pq.push_back(x);
            swim(pq.size()-1);
        }

        Key delMax() {
            // Add underflow check and resizing logic
            if(pq.size()==1)
               throw std::runtime_error("Priority queue underflow");

            // Exchange the root of the heap with the last element
            // and then sink the new root to restore heap order
            std::swap(pq[1], pq.back());
            const auto max = std::move(pq.back());
            pq.pop_back();
            sink(1);
            return max;
        }

    private:
        void swim(int k) {
            while (k > 1 && pq[k/2] < pq[k]) {
                std::swap(pq[k], pq[k/2]);
                k = k/2;
            }
        }

        void sink(int k) {
            int n = pq.size()-1;
            while (2*k <= n) {
                int j = 2*k;
                if (j < n && pq[j] < pq[j+1])
                    j++;
                if (!(pq[k] < pq[j])) break;
                std::swap(pq[k], pq[j]);
                k = j;
            }
        }

};
